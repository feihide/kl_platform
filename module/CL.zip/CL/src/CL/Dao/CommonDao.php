<?php
namespace CL\Dao;

use CL\Dao\BaseDao;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Select;
use Zend\Db\Adapter\Adapter;


class CommonDao extends BaseDao
{
	
	
}