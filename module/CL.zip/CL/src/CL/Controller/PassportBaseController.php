<?php
namespace CL\Controller;

class PassportBaseController extends BaseController
{
	
}