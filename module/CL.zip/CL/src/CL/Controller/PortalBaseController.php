<?php
/**
 * 基类控制器，存放公共方法，如果只对应单个模块，在继承该类生成单个模块对应的基类controller
 * 方法最好都是protected
 */
namespace CL\Controller;

class PortalBaseController extends BaseController{
	
	
	protected function userBaseTest(){
		
	}
	
	
	
}