<?php
/**
 * @author：Ethan <ethantsien@gmail.com>
 * @version：$Id: Server.php 19 2013-11-20 06:20:48Z quanwei $
 */

namespace CL\Ticket;

class Server
{
    protected $servers;

    public function __construct($config)
    {

    }
}
