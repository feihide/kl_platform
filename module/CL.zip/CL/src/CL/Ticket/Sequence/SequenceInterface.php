<?php
/**
 * @author：Ethan <ethantsien@gmail.com>
 * @version：$Id: SequenceInterface.php 19 2013-11-20 06:20:48Z quanwei $
 */

namespace CL\Ticket\Sequence;

interface SequenceInterface
{
    public function getName(); 
}
